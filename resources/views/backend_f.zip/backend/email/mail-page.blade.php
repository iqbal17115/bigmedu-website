<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h3>Web link: http://www.nanosoftbd.com/pm</h3>
	<h3>Email: {{$user_email  }}</h3>
	<h3>Password: {{$pass  }}</h3>

	<h3>Thanks,<br>
	The Nanosoft Development Team.</h3>

</body>
</html>