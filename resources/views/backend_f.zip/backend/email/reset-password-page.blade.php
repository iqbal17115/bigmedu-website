<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body><p>

	<h4>Hi {{$name}},</h4> 
	<h4>
		We received a request to reset your password.
		Enter the following password reset code:
	</h4>
	<br>
	<button class="btn btn-primary">{{$code}}</button><br>
	<h2>Thanks,<br>
	BIGM.</h2>



</body>
</html>