<p>Your Information:</p>
<div style="padding-left: 50px;">
	<p>Email: {{$email}}</p>
	<p>Password: {{$code}}</p>
</div>
<p><strong>You can can login with this email and password, Thank you</strong></p>